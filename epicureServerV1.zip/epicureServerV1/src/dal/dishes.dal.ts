import Dishes from "../db/models/dishes";

export class DishesDal {

    public createDish(dish: any) {
      dish = new Dishes({
        Name: dish.Name,
        DisheUrlImage: dish.DisheUrlImage,
        type: dish.type,
        DishDescription: dish.DishDescription,
        TimeToEat: dish.TimeToEat,
        RestaurantName: dish.RestaurantName,
        typeIcon: dish.typeIcon,
        IsSignatureDish: dish.IsSignatureDish,
        Price: dish.Price,   
        });

        dish.save(function (err: any, results: any) {
          return results;
        });
    }

    public async updateDish(dish:any) {
      const data = await Dishes.findOne({
        Name: dish.Name,
      }).updateOne({$set: {DishDescription: dish.DishDescription,},})
        return data
      }


    public findAll(query: any = null) {
        return Dishes.find(query);
      }
}


