import Chefs from "../db/models/chefs";

export class ChefsDal {

    public createChef(chef: any) {
        chef = new Chefs({
            ChefName: chef.ChefName,
            ImageURL: chef.ImageURL,
            TheShefDescription: chef.TheShefDescription,
            IsChefOfTheWeek: chef.IsChefOfTheWeek,
            IsNew: chef.IsNew,
            NumberOfView: chef.NumberOfView
          
        });

        chef.save(function (err: any, results: any) {
          return results;
        });
    }

    public async updateChef(chef:any) {
      const data = await Chefs.findOne({
        ChefName: chef.ChefName,
      }).updateOne({$set: {TheShefDescription: chef.TheShefDescription,},})
        return data
      }


    public findAll(query: any = null) {
        return Chefs.find(query);
      }
}


