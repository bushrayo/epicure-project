import Restaurants from "../db/models/restaurants";

export class RestaurantsDal {

    public createRestaurant(restaurant: any) {
        restaurant = new Restaurants({
          Name: restaurant.Name,
          ImageURL: restaurant.ImageURL,
          ChefName: restaurant.ChefName,
          OpeningHours: restaurant.OpeningHours,
          CloseingHour: restaurant.CloseingHour,
          IsFavorite: restaurant.IsFavorite,
          FoundedYear: restaurant.FoundedYear,
          location: restaurant.location
        });

        restaurant.save(function (err: any, results: any) {
          return results;
        });
    }

    public async updateRestaurant(restaurant:any) {
      await Restaurants.findOne({
        name: restaurant.name,
      }).updateOne({$set: {chef: restaurant.chef,}});
        const updatedRestaurants = await Restaurants.find();
        return updatedRestaurants;
    }


    public findAll() {
        return Restaurants.find();
    }
}


