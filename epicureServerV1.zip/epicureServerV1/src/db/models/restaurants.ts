import mongoose from 'mongoose';

const restaurantsSchema = new mongoose.Schema(
    {
      Name: {
        type: String,
        required: true
      },
      ImageURL: {
        type: String,
        required: true
      },
      ChefName: {
        type: String,
        required: true
      },
      OpeningHours: {
        type: String,
        required: true
      },
      CloseingHour: {
        type: String,
        required: true
      },
      IsFavorite: {
        type: Boolean,
        required: true
      },
    FoundedYear: {
        type: Number,
        required: true
      },
      location: {
        type: String,
        required: true
      }      
    },
    { timestamps: true }
  );
  
const Restaurants = mongoose.model('Restaurants', restaurantsSchema);
  
export default Restaurants;

