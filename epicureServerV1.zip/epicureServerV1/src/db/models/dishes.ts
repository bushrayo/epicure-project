import mongoose from 'mongoose';

const dishesSchema = new mongoose.Schema(
    {
      Name: {
        type: String,
        required: true
      },
      DisheUrlImage: {
        type: String,
        required: true
      },
      type: {
        type: String,
        required: true
      },
      DishDescription: {
        type: String,
        required: true
      },
      TimeToEat: {
        type: Array,
        required: true
      },
      RestaurantName: {
        type: String,
        required: true
      },
      typeIcon: {
        type: String,
        required: true
      },
      IsSignatureDish: {
        type: Boolean,
        required: true
      },
      Price: {
        type: Number,
        required: true
      },
    },
    { timestamps: true }
  );
  
const Dishes = mongoose.model('Dishes', dishesSchema);
  
export default Dishes;

