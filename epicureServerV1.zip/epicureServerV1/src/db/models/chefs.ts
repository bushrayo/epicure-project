import mongoose from 'mongoose';

const chefsSchema = new mongoose.Schema(
    {
      ChefName: {
        type: String,
        required: true
      },
      ImageURL: {
        type: String,
        required: true
      },
      TheShefDescription: {
        type: String,
        required: true
      },
      IsChefOfTheWeek: {
        type:  Boolean,
        required: true
      },
      
      IsNew: {
        type:  Boolean,
        required: true
      },
      NumberOfView: {
        type: Number,
        required: true
      },
    },
    { timestamps: true }
  );
  
const Chefs = mongoose.model('Chefs', chefsSchema);
  
export default Chefs;

