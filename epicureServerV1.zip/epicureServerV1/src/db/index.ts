import mongoose from "mongoose";
const connectDb = async () => {
await mongoose.connect("mongodb+srv://admin:1234@clustervs11.uqtfvuh.mongodb.net/test");

};
export { connectDb }