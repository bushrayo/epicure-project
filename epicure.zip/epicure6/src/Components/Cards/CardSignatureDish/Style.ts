import styled from 'styled-components';
interface imageSRCprops{
    srcImage? : string;
    shekelIcon? : string;
    type? : string;
   }
export const Body = styled.div`
display : flex;
flex-direction: column;
width: 100%;
height: 60vh;
margin: 0 auto;
align-items: center;
align-content: center;
justify-content: center;
justify-items: center;
margin-bottom: 10%;
padding: 1% 1% ;    
margin-right: 10%;
`;
export const ImageDiv = styled.div<imageSRCprops>`
background-image: url(${props => props.srcImage});
background-repeat:no-repeat;
width: 50vw;
height: 25vh;
`;

export const Details = styled.div`
    width: 50vw;
    height: 30vh;
    font-family: 'Helvetica Neue';
    font-style: normal;
    font-weight: 200;
    letter-spacing: 1.97px;
    color: #000000;
    background: #F9F4EA;
`;
export const TextDiv = styled.div`
width: 100%;
margin-top: 10%;
`;
export const Text = styled.h2`
    margin-top: 2%;
    width: 50vw;
    padding-top: 2%;
    font-family: 'Helvetica Neue';
    font-style: normal;
    font-weight: 200;
    letter-spacing: 1.97px;
    color: #000000;
`;
export const SText = styled.h4`
    margin-top: 2%;
    width: 50vw;
    padding-top: 2%;
    font-family: 'Helvetica Neue';
    font-style: normal;
    font-weight: 150;
    letter-spacing: 1.97px;
    color: #000000;
    
`;

export const ShekelText = styled(SText)`
height: 3vh;
width: 5vw;
margin-left: 1vw;
    
`;

export const SpicyIcon = styled.div<imageSRCprops>`
background-image: url(${props => props.type});
background-repeat:no-repeat;
width: 7vw;
height:7vh;
margin-bottom:3vh;
position: absolute;
bottom: 4vh;
margin-left: 2vw;
`;

export const PriceDiv = styled.div`
width: 30vw;
display : flex;
flex-direction: row;
align-items: left;
justify-content: flex-start;
position: absolute;
bottom: 4vh;
margin-left: 2vw;

`;