import React, { useState } from "react";
import { shekelIcon } from "../../../services/imagesURL";
import {
  Body,
  ImageDiv,
  TextDiv,
  Text,
  SText,
  Details,
  SpicyIcon,
  PriceDiv,
  ShekelText,
} from "./Style";

interface Props {
  theObj: object;
}

export default function CardSignatureDish(props: Props) {
  let Name: string = "";
  let UrlImage: string = "";
  let Description: string = "";
  let TypeIcon: string = "";
  let Price: string = "";

  Object.entries(props.theObj).map(([key, value]) => {
    if (key === "Name") Name = value;
    if (key === "UrlImage") UrlImage = value;
    if (key === "Description") Description = value;
    if (key === "TypeIcon") TypeIcon = value;
    if (key === "Price") Price = "₪" + value;
  });

  return (
    <Body>
      <ImageDiv srcImage={UrlImage}></ImageDiv>
      <Details>
        <TextDiv>
          <Text>{Name}</Text>
        </TextDiv>

        <TextDiv>
          <SText>{Description}</SText>
        </TextDiv>

        <SpicyIcon type={TypeIcon}></SpicyIcon>

        <PriceDiv>
          <ShekelText>{Price}</ShekelText>
        </PriceDiv>
      </Details>
    </Body>
  );
}
