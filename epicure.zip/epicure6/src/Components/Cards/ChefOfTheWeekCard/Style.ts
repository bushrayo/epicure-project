import styled from 'styled-components';
interface imageSRCprops{
    srcImage?: string;
   }
export const Body = styled.div`
display : flex;
flex-direction: column;
width: 100%;
height: 35vh;
margin: 0 auto;
align-items: center;
align-content: center;
justify-content: center;
justify-items: center;
margin-bottom: 10%;
padding: 1% 1% ;    
margin-right: 10%;
`;
export const ImageDiv = styled.div<imageSRCprops>`
background-image: url(${props => props.srcImage});
width: 50vw;
height: 25vh;
`;

export const Details = styled.div`
height: 10vh;
width: 50vw;
display: flex;
flex-direction: column;
align-items: flex-start;
background: #F9F4EA;
`;
export const Text = styled.h2`
    margin-top: 3%;
    width: 50vw;
    padding-top: 2%;
    font-family: 'Helvetica Neue';
    font-style: normal;
    font-weight: 200;
    letter-spacing: 1.97px;
    color: #000000;
`;

