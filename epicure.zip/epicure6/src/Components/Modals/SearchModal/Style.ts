import styled from 'styled-components';


export const Body = styled.div`
display : flex;
flex-direction: column;
width: 100%;
margin: 0 auto;
position: fixed;    
 width: 100vw; 
 top: 0;
 left: 0;
 background: #FFFFFF;
 margin-bottom: 1%;
 height: 60vh;
 z-index:10000;
`;
export const Header = styled.div`
display : flex;
flex-direction: row;
justify-content: space-around;
top: 0;
left: 0;
width: 60%;


`;

export const Button = styled.button`
    margin-top: 1%;
    margin-left: 1%;
    border: none;
    background-color: none;
    `;

export const Address = styled.h3`
justify-content: center;

`;

export const SearchDiv = styled.div`
width: 100%;
margin-top: 5%;
text-align: center;
`;
export const Input = styled.input`
width: 80%;
height: 3vh;
margin-bottom: 3%;
border: 1px solid;
background-image:url("./Assets/images/searchIcon.svg");   
background-position:left ;   
background-repeat:no-repeat;   


`;

export const Result = styled.div`
width: 70%;
margin-top: 5%;
border:px solid;
align-items: center;
background-color: #FAFAFA;

`;




