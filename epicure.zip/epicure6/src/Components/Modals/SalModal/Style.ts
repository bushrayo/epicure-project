import styled from 'styled-components';


export const Body = styled.div`
display : flex;
flex-direction: column;
margin: 0 auto;
position: absolute;    
 width: 100vw; 
 top: 5vh; 
 
 left: 0;
 background: #FFFFFF;
 height: 35vh;
 align-items: center;
justify-content: center;

`;

interface imageSRCprops{
    src?: string;
}
export const BagDiv = styled.div`
display : flex;
flex-direction: column;
align-items: center;
justify-content: center;
height: 100%;
width: 100%;
`;
export const BagImage = styled.div<imageSRCprops>`
  background-image: url(${props => props.src});
  background-position:center ;
  width: 15vw;    
  height: 7vh;
  background-repeat:no-repeat;
  align-self: center; 
  justify-content: center;
    
`;
export const BagDetailsDiv = styled.div`
  width: 10vw;    
  height: 5vh;
  align-self: center;  
  justify-content: center;
   
`;
export const BagDetailsTitle = styled.h2`
justify-content: center;
font-family: 'Helvetica Neue';
font-style: normal;
font-weight: 200;
font-size: 16px;
text-align: center;
letter-spacing: 2.67px;
text-transform: uppercase;
color: black;
   
`;