import styled from 'styled-components';
interface imageSRCprops{
    shefImage?: string;
   }
export const Body = styled.div`
display : flex;
flex-direction: column;
width: 100%;
height: 75vh;
margin: 0 auto;
align-items: center;
align-content: center;
justify-content: center;
justify-items: center;
margin-bottom: 20%;
margin-top: 10vh;

`;

export const TextHeader=styled.h1`
    margin-top: 2%;
    width: 90%;     
    padding-top: 2%;
    font-family: 'Helvetica Neue';
    font-style: normal;
    font-weight: 200;
    font-size: 16px;
    line-height: 20px;
    letter-spacing: 1.2px;
    color: #000000;
    height: 5vh;
    text-align: left;
    margin-left: 5%;
  
`;

export const ShefImageDiv = styled.div<imageSRCprops>`
background-image: url(${props => props.shefImage});
background-repeat:no-repeat;
background-size: cover;
width: 80vw;
height: 25vh;
`;
export const ChefNameBlock = styled.div`
display: flex;
position: relative;
width: 100%;    
 background: rgba(255, 255, 255, 0.8);
height: 5vh;
top: 20vh;
text-align: center;
align-items: center;
align-content: center;
justify-content: center;

`;
export const ChefName=styled.h1`
margin-top: 2%;
margin-bottom: 3%;
width: 100%;
height: 10%;
display: block;
padding-top: 2%;
font-family: 'Helvetica Neue';
font-style: normal;
font-weight: 200;
font-size: 18px;
line-height: 10px;
letter-spacing: 1.97px;
color: #000000;

`;

export const Paragraph=styled.p`
margin-top: 2%;
margin-bottom: 3%;
width: 75vw;
padding-top: 2%;
font-family: 'Helvetica Neue';
font-style: normal;
font-weight: 200;
font-size: 12px;
line-height: 5vw;
letter-spacing: 1.97px;
color: #000000;
`;


export const CaruselaDiv=styled.div`
width: 95%;
height: 55vh;

`;
