import React from "react";
import Carusela from "../Carusela/Carusela";
import { ChefsArray, DishesDataArray } from "../../services/RestuarantsData";
import {
  Body,
  TextHeader,
  CaruselaDiv,
  ShefImageDiv,
  ChefNameBlock,
  ChefName,
  Paragraph,
} from "./Style";

export default function ChefOfTheWeek() {
  const ChefOfTheWeekArrayDishes: object[] = [];
  const theCaruselaType: string = "ChefOfTheWeek";
  const address: string = "Chef Of The Week: ";
  let TheChefOfTheWeekObject: any = [];
  TheChefOfTheWeekObject = ChefsArray.filter(
    (el) => el.IsChefOfTheWeek === true
  );

  DishesDataArray.filter(
    (el) => el.ChefName === TheChefOfTheWeekObject[0].ChefName
  ).map((DishData) => {
    ChefOfTheWeekArrayDishes.push({
      DishName: DishData.Name,
      ImageURL: DishData.DisheUrlImage,
    });
  });

  let shefImage = TheChefOfTheWeekObject[0].ImageURL;
  let chefName = TheChefOfTheWeekObject[0].ChefName;
  let TheShefDescription = TheChefOfTheWeekObject[0].TheShefDescription;

  return (
    <Body>
      <TextHeader>{address}</TextHeader>
      <div>
        <ShefImageDiv shefImage={shefImage}>
          <ChefNameBlock>
            <ChefName>{chefName}</ChefName>
          </ChefNameBlock>
        </ShefImageDiv>
      </div>
      <Paragraph>{TheShefDescription} </Paragraph>
      <Paragraph>{address} </Paragraph>

      <CaruselaDiv>
        <Carusela
          TheArray={ChefOfTheWeekArrayDishes}
          caruselaType={theCaruselaType}
        />
      </CaruselaDiv>
    </Body>
  );
}
