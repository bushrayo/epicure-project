import React from "react";
import MobileHome from "../MobileHome/MobileHome";
import DesktopPage from "../DesktopPage/DesktopPage";
import WindowSize from "../../helpers/WindowSize";

export default function Home() {
  const windowSize = WindowSize();
  return <div>{windowSize < 700 ? <MobileHome /> : <DesktopPage />}</div>;
}
