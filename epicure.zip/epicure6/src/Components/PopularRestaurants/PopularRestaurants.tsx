import React from "react";
import Carusela from "../Carusela/Carusela";
import { RestuarantsDataArray } from "../../services/RestuarantsData";
import { Body, TextHeader, CaruselaDiv } from "./style";

export default function PopularRestaurants() {
  const ThePopularRestaurantsArray: object[] = [];
  const theCaruselaType: string = "PopularRestaurants";
  const address: string = "popular restaurant in epicure:";

  RestuarantsDataArray.filter((el) => el.IsFavorite === true).map(
    (favResturant) => {
      ThePopularRestaurantsArray.push({
        Name: favResturant.Name,
        ImageURL: favResturant.ImageURL,
        ChefName: favResturant.ChefName,
      });
    }
  );

  return (
    <Body>
      <TextHeader>{address}</TextHeader>

      <CaruselaDiv>
        <Carusela
          TheArray={ThePopularRestaurantsArray}
          caruselaType={theCaruselaType}
        />
      </CaruselaDiv>
    </Body>
  );
}
