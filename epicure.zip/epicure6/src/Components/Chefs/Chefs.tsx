import React from "react";
import "./Style.ts";

export default function Chefs() {
  return (
    <div style={{ textAlign: "center" }}>
      <p>chefs</p>
    </div>
  );
}
