import React from "react";
import "./iconStyle.css";

export default function IconsComponent() {
  const SpicyIcon: string = "./Assets/images/SpicyIcon.png";
  const VegitarianIcon: string = "./Assets/images/VegitarianIcon.png";
  const VeganIcon: string = "./Assets/images/VeganIcon.png";
  return (
    <div className="iconMain">
      <h1>Icons meaning</h1>
      <img src={SpicyIcon} alt="Spicy" />
      <h3>Spicy</h3>
      <img src={VegitarianIcon} alt="Vegitarian" />
      <h3>Vegitarian</h3>
      <img src={VeganIcon} alt="Vegan" />
      <h3>Vegan</h3>
    </div>
  );
}
