import React from "react";

export default function DesktopPage() {
  return <div>DesktopPage</div>;
}
