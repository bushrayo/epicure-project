import React from "react";
import { logo, AppStore, GooglePlay } from "../../services/imagesURL";
import { Body, Address, ImageDiv, Paragraph } from "./Style";

export default function DownloadsComponent() {
  const address: string = "About Us:";
  const aboutUSparagraph: string =
    "Lorem ipsum dolor sit amet, consectetur adipiscing elit. In a lacus vel justo fermentum bibendum non eu ipsum. Cras porta malesuada eros, eget blandit turpis suscipit at. Vestibulum sed massa in magna sodales porta. Vivamus elit urna, dignissim a vestibulum.";

  return (
    <Body>
      <ImageDiv logo={logo} />
      <ImageDiv logo={AppStore} />
      <ImageDiv logo={GooglePlay} />
      <Address>{address} </Address>
      <Paragraph>{aboutUSparagraph} </Paragraph>
    </Body>
  );
}
