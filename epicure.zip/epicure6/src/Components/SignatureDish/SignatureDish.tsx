import React from "react";
import { Body, TextHeader, CaruselaDiv } from "./Style";
import { DishesDataArray } from "../../services/RestuarantsData";
import Carusela from "../Carusela/Carusela";

export default function SignatureDish() {
  const TheSignatureDishArray: object[] = [];
  const theSignatureDish: string = "SignatureDish";
  const address: string = "SIGNATURE DISH OF:";

  DishesDataArray.filter((el) => el.IsSignatureDish === true).map(
    (SignatureDish) => {
      TheSignatureDishArray.push({
        Name: SignatureDish.Name,
        Description: SignatureDish.DishDescription,
        UrlImage: SignatureDish.DisheUrlImage,
        TypeIcon: SignatureDish.typeIcon,
        Price: SignatureDish.Price,
      });
    }
  );

  return (
    <Body>
      <TextHeader>{address}</TextHeader>

      <CaruselaDiv>
        <Carusela
          TheArray={TheSignatureDishArray}
          caruselaType={theSignatureDish}
        />
      </CaruselaDiv>
    </Body>
  );
}
