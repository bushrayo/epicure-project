import React from "react";
import { Body, SearchBlock, TextHeader, Input } from "./Style";
import { heroPicture, searchIcon } from "../../services/imagesURL";

export default function HeroMobile() {
  const [inputSearchValue, setInputSearcValue] = React.useState("");
  const address: string =
    "Epicure works with the top chef restaurants in Tel Aviv";
  const paragraphInInput: string = "     Search for restaurant cuisine, chef";

  const onChangeHandler = (e: React.ChangeEvent<HTMLInputElement>) => {
    setInputSearcValue(e.target.value);
  };

  return (
    <Body srcImage={heroPicture}>
      <SearchBlock>
        <TextHeader>{address}</TextHeader>
        <Input
          searchIcon={searchIcon}
          placeholder={paragraphInInput}
          type="text"
          value={inputSearchValue}
          name="search"
          onChange={onChangeHandler}
        />
      </SearchBlock>
    </Body>
  );
}
