import React from "react";
import { useNavigate } from "react-router-dom";
import Container from "../Container/Container";
import "./Style";

export default function Restaurants() {
  const navigate = useNavigate();
  const goToHome = () => {
    navigate("/");
  };

  return (
    <div style={{ textAlign: "center" }}>
      <p>resturant</p>
    </div>
  );
}
