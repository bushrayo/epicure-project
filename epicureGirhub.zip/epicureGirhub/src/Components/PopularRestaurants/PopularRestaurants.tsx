import React from "react";
import Carusela from "../Carusela/Carusela";
import { RestuarantsDataArray } from "../../services/RestuarantsData";
import { Body, TextHeader, CaruselaDiv } from "./MobileStyle";
import { DesktopPopularRestaurants } from "./DesktopStyle";
import WindowSize from "../../helpers/WindowSize";
import CardPopular from "../Cards/CardPopular/CardPopular";

export default function PopularRestaurants() {
  const windowSize = WindowSize();
  const ThePopularRestaurantsArray: object[] = [];
  const theCaruselaType: string = "PopularRestaurants";
  const address: string = "popular restaurant in epicure:";

  RestuarantsDataArray.filter((el) => el.IsFavorite === true)
    .slice(0, 3)
    .map((favResturant) => {
      ThePopularRestaurantsArray.push({
        Name: favResturant.Name,
        ImageURL: favResturant.ImageURL,
        ChefName: favResturant.ChefName,
      });
    });

  return (
    <Body>
      <TextHeader>{address}</TextHeader>
      {windowSize < 768 ? (
        <CaruselaDiv>
          <Carusela
            TheArray={ThePopularRestaurantsArray}
            caruselaType={theCaruselaType}
          />
        </CaruselaDiv>
      ) : (
        <DesktopPopularRestaurants>
          {ThePopularRestaurantsArray.map((obj) => (
            <CardPopular theObj={obj} />
          ))}
        </DesktopPopularRestaurants>
      )}
    </Body>
  );
}
