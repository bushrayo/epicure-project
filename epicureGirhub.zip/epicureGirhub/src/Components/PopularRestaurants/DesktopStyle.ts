import styled from 'styled-components';

export const DesktopPopularRestaurants = styled.div`
display : flex;
flex-direction: row;
width: 90%;
height: 45vh;
margin: 0 auto;
align-items: center;
align-content: center;
justify-content: center;
justify-items: center;
margin-bottom: 3%;

`;

