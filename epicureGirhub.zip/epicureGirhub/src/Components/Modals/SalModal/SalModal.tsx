import React, { useState } from "react";
import { bagImage } from "../../../services/imagesURL";
import {
  Body,
  BagDiv,
  BagImage,
  BagDetailsDiv,
  BagDetailsTitle,
} from "./Style";

interface Props {
  setShowSalModal: (params: any) => any;
}
export default function SalModal({ setShowSalModal }: Props) {
  const hideSalModal = () => {
    setShowSalModal(false);
  };

  return (
    <Body onClick={hideSalModal}>
      <BagDiv>
        <BagImage src={bagImage} />
        <BagDetailsDiv>
          <BagDetailsTitle> Your bag is empty</BagDetailsTitle>
        </BagDetailsDiv>
      </BagDiv>
    </Body>
  );
}
