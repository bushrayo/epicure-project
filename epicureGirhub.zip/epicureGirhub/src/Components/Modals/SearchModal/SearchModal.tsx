import React, { useState } from "react";

import {
  Body,
  Header,
  Button,
  Address,
  SearchDiv,
  Input,
  Result,
} from "./Style";
interface Props {
  setShowSearchModal: (params: any) => any;
}
export default function SearchModal({ setShowSearchModal }: Props) {
  const [searchInput, setSearchInput] = useState("");
  const [showResult, setShowResult] = useState(false);

  const hideSearch = () => {
    setShowSearchModal(false);
  };

  function handleChange(e: {
    target: { value: React.SetStateAction<string> };
  }) {
    setShowResult(true);
    setSearchInput(e.target.value);
  }
  return (
    <Body>
      <Header>
        <Button onClick={hideSearch}> X </Button>

        <Address>Search</Address>
      </Header>
      <SearchDiv>
        <Input
          type="text"
          name="search"
          onChange={handleChange}
          value={searchInput}
        />

        {showResult && <Result>{searchInput}</Result>}
      </SearchDiv>
    </Body>
  );
}
