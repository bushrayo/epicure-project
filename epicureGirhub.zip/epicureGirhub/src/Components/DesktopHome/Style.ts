import styled from 'styled-components';

export const Body = styled.div`
 margin:0;
 display:flex; 
 flex-direction:column; 
 text-align: left;

`;