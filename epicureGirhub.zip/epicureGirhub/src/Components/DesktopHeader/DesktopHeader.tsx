import React, { useState } from "react";

import {
  logoURL,
  EPICURE,
  searchIcon,
  LoginIcon,
  BagIcon,
} from "../../services/imagesURL";
import {
  Navbar,
  RightIcons,
  Links,
  IconsLinks,
  LeftIcons,
  Block,
  LogoDiv,
  EpicureDiv,
} from "./Style";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faBars } from "@fortawesome/free-solid-svg-icons";
import SearchModal from "../Modals/SearchModal/SearchModal";
import SignInModal from "../Modals/SignInModal/SignInModal";
import SalModal from "../Modals/SalModal/SalModal";
import { useNavigate } from "react-router-dom";

export default function Header() {
  const navigate = useNavigate();
  const [ShowSearchModal, setShowSearchModal] = useState(false);
  const [ShowLoginModal, setShowLoginModal] = useState(false);
  const [ShowSalModal, setShowSalModal] = useState(false);

  const showSearch = () => {
    setShowSearchModal(true);
  };

  const showLoginPage = () => {
    setShowLoginModal(true);
  };
  const showSalPage = () => {
    setShowSalModal(true);
  };

  return (
    <div>
      <Navbar>
        <LeftIcons>
          <IconsLinks to="/home">
            {/* <img
              src={logoURL}
              alt="logo"
              style={{ width: "4vw", height: "4vh" }}
            /> */}
            <LogoDiv srcImage={logoURL} />
          </IconsLinks>
          <IconsLinks to="/home">
            <EpicureDiv srcImage={EPICURE} />
          </IconsLinks>

          <Links to="/restaurants">Restaurants</Links>
          <Links to="/chefs"> Chefs </Links>
        </LeftIcons>

        <Block>
          <RightIcons>
            <IconsLinks to="#Search" onClick={showSearch}>
              <img src={searchIcon} alt="logo" />
            </IconsLinks>

            <IconsLinks to="#Login" onClick={showLoginPage}>
              <img src={LoginIcon} alt="logo" />
            </IconsLinks>

            <IconsLinks to="#Bag" onClick={showSalPage}>
              <img src={BagIcon} alt="logo" />
            </IconsLinks>
          </RightIcons>
        </Block>
      </Navbar>
      {ShowSearchModal && (
        <SearchModal setShowSearchModal={setShowSearchModal} />
      )}
      {ShowLoginModal && <SignInModal setShowSignInModal={setShowLoginModal} />}
      {ShowSalModal && <SalModal setShowSalModal={setShowSalModal} />}
    </div>
  );
}
