import styled from 'styled-components';


export const Body = styled.div`
display : block;
width: 100%;
margin: 0 auto;
align-items: center;
align-content: center;
justify-content: center;
justify-items: center;
`;
