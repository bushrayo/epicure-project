import React from "react";
import { Body, IconsDiv, EachIconsDiv, Address, Text, ImageDiv } from "./Style";
import { SpicyIcon, VegitarianIcon, VeganIcon } from "../../services/imagesURL";

export default function IconsComponent() {
  return (
    <Body>
      <Address>Icons meaning</Address>

      <IconsDiv>
        <EachIconsDiv>
          <ImageDiv srcImage={SpicyIcon} />
          <Text>Spicy</Text>
        </EachIconsDiv>

        <EachIconsDiv>
          <ImageDiv srcImage={VegitarianIcon} />
          <Text>Vegitarian</Text>
        </EachIconsDiv>

        <EachIconsDiv>
          <ImageDiv srcImage={VeganIcon} />
          <Text>Vegan</Text>
        </EachIconsDiv>
      </IconsDiv>
    </Body>
  );
}

// return (
//   <div className="iconMain">
//     <h1>Icons meaning</h1>
//     <img src={SpicyIcon} alt="Spicy" />
//     <h3>Spicy</h3>
//     <img src={VegitarianIcon} alt="Vegitarian" />
//     <h3>Vegitarian</h3>
//     <img src={VeganIcon} alt="Vegan" />
//     <h3>Vegan</h3>
//   </div>
// );
// }
