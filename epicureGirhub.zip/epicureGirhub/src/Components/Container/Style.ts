import styled from 'styled-components';

export const Body = styled.div`

`;

export const Button = styled.button`
margin-left: 3vw;
margin-bottom: 5vw;
margin-top: 2vw;
background: none;
  border: none;
`;
