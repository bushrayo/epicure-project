import styled from 'styled-components';

export const DesktopSignatureDish = styled.div`
display : flex;
flex-direction: row;
width: 90%;
height: 50vh;
margin: 0 auto;
align-items: center;
align-content: center;
justify-content: center;
justify-items: center;
margin-bottom: 3%;

`;

