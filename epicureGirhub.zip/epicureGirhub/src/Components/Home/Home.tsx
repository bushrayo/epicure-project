import React from "react";
import MobileHome from "../MobileHome/MobileHome";
import DesktopHome from "../DesktopHome/DesktopHome";
import WindowSize from "../../helpers/WindowSize";

export default function Home() {
  const windowSize = WindowSize();
  return <div>{windowSize < 768 ? <MobileHome /> : <DesktopHome />}</div>;
}
