const country = 'Austria';

export {}; // 👈️ if you don't have anything else to export