import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import { Body, AddressDiv, Address, NavDiv, MachRestaurantsDiv } from "./Style";
import NavBarRestaurants from "./NavBar/NavBarRestaurants";
import { RestuarantsDataArray } from "../../services/RestuarantsData";
import Card from "../Cards/ResturantsPageCard/Card";

export default function Restaurants() {
  const [clickedLink, setClickedLink] = useState("All");
  const navigate = useNavigate();
  const AllTheRestaurantsArray: object[] = RestuarantsDataArray;
  const NewRestaurantsArray: object[] = RestuarantsDataArray.filter(
    (el) => el.IsNew === true
  );
  const OpenRestaurantsArray: object[] = RestuarantsDataArray.filter(
    (el) => el.IsOpenNow === true
  );
  const PupularRestaurantsArray: object[] = RestuarantsDataArray.filter(
    (el) => el.IsFavorite === true
  );
  let arrayToShow: object[] = [];

  const chooseFilter = () => {
    switch (clickedLink) {
      case "All":
        arrayToShow = AllTheRestaurantsArray;
        break;
      case "New":
        arrayToShow = NewRestaurantsArray;
        break;
      case "Popular":
        arrayToShow = PupularRestaurantsArray;
        break;
      case "Open":
        arrayToShow = OpenRestaurantsArray;
        break;
    }
  };
  chooseFilter();

  return (
    <Body>
      <AddressDiv>
        <Address>resturant</Address>
      </AddressDiv>
      <NavDiv>
        <NavBarRestaurants setClickedLink={setClickedLink} />
      </NavDiv>
      <MachRestaurantsDiv>
        {arrayToShow.map((obj) => (
          <Card theObj={obj} />
        ))}
      </MachRestaurantsDiv>
    </Body>
  );
}
