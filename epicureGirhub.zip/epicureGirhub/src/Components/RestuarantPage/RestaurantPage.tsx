import React from "react";

export default function RestaurantPage() {
  return <div>RestaurantPage</div>;
}
