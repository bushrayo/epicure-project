export const navBarLogo='navBarLogo.svg'; 
export const heroPicture="./Assets/images/heroPicture.svg"; 
export const logoURL= "./Assets/images/navBarLogo.svg";
export const searchIcon= "./Assets/images/searchIcon.svg";
export const LoginIcon= "./Assets/images/LoginIcon.svg";
export const BagIcon= "./Assets/images/BagIcon.svg";
export const line= "./Assets/images/line.svg";
export const bagImage= "./Assets/images/Sal.svg";
export const shekelIcon= "./Assets/images/shekel.svg";
export const SpicyIcon= "./Assets/images/SpicyIcon.png";
export const VegitarianIcon = "./Assets/images/VegitarianIcon.png";
export const VeganIcon = "./Assets/images/VeganIcon.png";
export const logo = "./Assets/images/logo.svg";
export const EPICURE = "./Assets/images/EPICURE.svg";
export  const AppStore= "./Assets/images/AppStore.png";
export  const GooglePlay = "./Assets/images/GooglePlay.png";


 


//restaurants

export  const claroRestaurant = "./Assets/images/restaurantsImage/claro.svg";
export  const Kabkem = "./Assets/images/restaurantsImage/Kabkem.svg";
export  const Messa = "./Assets/images/restaurantsImage/Messa.svg";
export  const nithanThai = "./Assets/images/restaurantsImage/nithanThai.svg";
export  const tigerlily = "./Assets/images/restaurantsImage/tigerlily.svg";
export  const Yapan = "./Assets/images/restaurantsImage/Yapan.svg";
export  const Lumina = "./Assets/images/restaurantsImage/Lumina.svg";


//shef's name

export  const AsafGranit = './Assets/images/shefImage/AsafGranit.svg';
export  const OmerMiller = './Assets/images/shefImage/OmerMiller.svg';
export  const MeirAdoni = './Assets/images/shefImage/MeirAdoni.svg';
export  const ShahafShabtay = './Assets/images/shefImage/ShahafShabtay.svg';
export  const EyalShani = './Assets/images/shefImage/EyalShani.svg';
export  const AvivMoshe = './Assets/images/shefImage/AvivMoshe.svg';
    
  
